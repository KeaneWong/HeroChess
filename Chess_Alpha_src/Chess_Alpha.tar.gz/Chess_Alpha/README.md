# HeroChess v1.0
A chess software program. 

**Update History:**

04/25/2021 - Initial Version

**Authors:**
* Irania Mazariegos
* Keane Wong
* Mario Tafoya 
* Paul Lee
* Rachel Villamor

This is the alpha version of the chess software, to install, please type "make" on the command line.
For more detailed instructions, please refer to the user manual.

Enjoy!
