# Installation Instructions

On the terminal type `tar -xvzf Chess_Alpha_src.tar.gz`. 

Then, press enter and type `cd Chess_Alpha_src`. 

Finally, press enter and type `make`.
