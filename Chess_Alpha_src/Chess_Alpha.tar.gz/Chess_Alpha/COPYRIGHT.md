# Copyright

<p align="center">
  <b>HeroChess Version 1.0, April 2021</b>
</p>

Copyright (C) 2021, Avengineers. All rights reserved.
This installation is protected by U.S and International Copyright laws. Reproduction and
distribution of the project without written permission of the sponsor is prohibited.

**Authors:**
* Irania Mazariegos
* Keane Wong
* Mario Tafoya 
* Paul Lee
* Rachel Villamor
