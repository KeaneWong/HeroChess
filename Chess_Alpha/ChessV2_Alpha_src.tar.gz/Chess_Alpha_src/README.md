# HeroChess v2.0
A chess software program. 

**Update History:**

**MM/DD/YYYY - Description**

05/31/2021 - Alpha Release Version

**Authors:**
* Irania Mazariegos
* Keane Wong
* Paul Lee
* Rachel Villamor

This is the 2.0 version of the chess software, to install, please refer to the INSTALL.md document.

Enjoy!

