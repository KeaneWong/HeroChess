# Copyright

<p align="center">
  <b>HeroChess Version 2.0, May 2021</b>
</p>

Copyright (C) 2021, Avengineers. All rights reserved.
This installation is protected by U.S and International Copyright laws. Reproduction and
distribution of the project without written permission of the sponsor is prohibited.

**Authors:**
* Irania Mazariegos
* Keane Wong 
* Paul Lee
* Rachel Villamor
