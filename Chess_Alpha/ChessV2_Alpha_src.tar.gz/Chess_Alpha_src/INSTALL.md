# Installation Instructions

On the terminal type `tar -xvzf Chess_V2.0.tar.gz` and press enter. 

Then, type `cd Chess_V2.0` and press enter. 

Finally, type `make` and press enter. Installation is now complete.

To run the game, type `./bin/HeroChess`, press enter, and enjoy the game.

