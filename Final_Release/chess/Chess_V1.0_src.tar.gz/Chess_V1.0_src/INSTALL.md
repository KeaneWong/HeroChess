# Installation Instructions

On the terminal type `tar -xvzf Chess_V1.0_src.tar.gz` and press enter. 

Then, type `cd Chess_V1.0_src` and press enter. 

Finally, type `make` and press enter. Installation is now complete.

To run the game, type `./bin/HeroChess`, press enter, and enjoy the game.

