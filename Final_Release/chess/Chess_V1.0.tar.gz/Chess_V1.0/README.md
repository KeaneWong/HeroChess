# HeroChess v1.0
A chess software program. 

**Update History:**

**MM/DD/YYYY - Description**

05/09/2021 - Final Release Version

04/25/2021 - Initial Version

**Authors:**
* Irania Mazariegos
* Keane Wong
* Mario Tafoya 
* Paul Lee
* Rachel Villamor

This is the 1.0 version of the chess software, to install, please refer to the INSTALL.md document.

Enjoy!
