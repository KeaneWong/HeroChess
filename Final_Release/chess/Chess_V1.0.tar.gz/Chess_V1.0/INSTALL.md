# Installation Instructions

On the terminal type `tar -xvzf Chess_V1.0.tar.gz` and press enter. 

Then, type `cd Chess_V1.0` and press enter. 

Finally, type `make` and press enter. Installation is now complete.

To run the game, type `./bin/chess`, press enter, and enjoy the game.
